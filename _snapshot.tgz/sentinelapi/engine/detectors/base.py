from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

# Maps finding_class to a vuln_id used by fix toggles
VULN_ID_MAP = {
    "BOLA": "bola_orders",
    "BFLA": "bfla_admin",
    "EXCESSIVE_DATA_EXPOSURE": "exposure_me",
    "BROKEN_AUTH": "auth_invoices",
    "RATE_LIMITING": "ratelimit",
    "MISCONFIGURATION": "misconfig",
}

@dataclass
class FindingCandidate:
    finding_class: str
    owasp_id: str
    endpoint_path: str
    endpoint_method: str
    operation_id: str
    title: str
    impact: str
    remediation: str
    expected: str
    actual: str
    severity: str
    risk_score: float
    confidence: str  # "VERIFIED" or "POTENTIAL"
    score_factors: List[Any] = field(default_factory=list)  # Can be str keys OR dicts
    probes: List[Dict[str, Any]] = field(default_factory=list)
    fingerprint: str = ""

    @property
    def vuln_id(self) -> str:
        """Map finding class to the SentinelShop fix toggle key."""
        base = VULN_ID_MAP.get(self.finding_class, self.finding_class.lower())
        # Make unique per endpoint
        if "users" in self.endpoint_path.lower() and self.finding_class == "BOLA":
            return "bola_users"
        return base

    @property
    def endpoint(self) -> str:
        """Return 'METHOD /path' for display."""
        return f"{self.endpoint_method} {self.endpoint_path}"

class BaseDetector:
    def __init__(self, name: str, owasp_id: str):
        self.name = name
        self.owasp_id = owasp_id
