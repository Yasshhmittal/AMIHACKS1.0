from fastapi import APIRouter, HTTPException
import httpx
from typing import Optional, Dict, Any

from ..models.schemas import FindingResponse, FindingPoCResponse, AIExplainResponse, ScoreFactor, ProbeModel
from ..core.evidence import build_curl_poc, build_httpie_poc, build_python_poc
from ..ai.groq_provider import GroqProvider
from .scans import scan_in_memory_results, scan_metadata, _finding_to_response

router = APIRouter(prefix="/api/findings", tags=["findings"])
ai_provider = GroqProvider()

def find_in_memory_finding(finding_id: int):
    """Find a finding by ID across all scans. Returns (finding, scan_id) tuple."""
    for scan_id, scan_res in scan_in_memory_results.items():
        findings = scan_res.get("findings", [])
        if 1 <= finding_id <= len(findings):
            return findings[finding_id - 1], scan_id
    return None, None

@router.get("/{finding_id}", response_model=FindingResponse)
async def get_finding_detail(finding_id: int):
    f, scan_id = find_in_memory_finding(finding_id)
    if not f:
        raise HTTPException(status_code=404, detail="Finding not found")

    return _finding_to_response(f, finding_id, scan_id or 1)

@router.get("/{finding_id}/poc", response_model=FindingPoCResponse)
async def get_finding_poc(finding_id: int):
    f, scan_id = find_in_memory_finding(finding_id)

    # Determine target URL from scan metadata
    target_base = "http://localhost:4000"
    if scan_id and scan_id in scan_metadata:
        target_base = scan_metadata[scan_id].get("target_url", target_base)

    method = "GET"
    path = "/orders/102"
    if f:
        method = f.endpoint_method
        path = f.endpoint_path
        # Substitute common path params for the PoC
        for param in ["order_id", "id", "user_id"]:
            path = path.replace("{" + param + "}", "102")

    url = f"{target_base}{path}"
    headers = {"Authorization": "Bearer $USER_A_TOKEN"}
    return FindingPoCResponse(
        finding_id=finding_id,
        curl=build_curl_poc(method, url, headers, token_placeholder="$USER_A_TOKEN"),
        httpie=build_httpie_poc(method, url, headers),
        python_code=build_python_poc(method, url, headers)
    )

@router.post("/{finding_id}/verify")
async def verify_finding(finding_id: int):
    """
    CRITICAL DEMO MOMENT:
    Re-executes the live HTTP request against the actual target to verify whether
    the flaw is STILL VULNERABLE or FIXED! Never returns a cached result.
    """
    f, scan_id = find_in_memory_finding(finding_id)

    # Determine target URL from scan metadata
    target_base = "http://localhost:4000"
    if scan_id and scan_id in scan_metadata:
        target_base = scan_metadata[scan_id].get("target_url", target_base)

    method = "GET"
    endpoint_path = "/orders/102"
    headers = {"Authorization": "Bearer token-alice-12345"}

    if f:
        method = f.endpoint_method
        path = f.endpoint_path
        for param in ["order_id", "id", "user_id"]:
            path = path.replace("{" + param + "}", "102")
        endpoint_path = path

    async with httpx.AsyncClient(timeout=5.0) as client:
        try:
            res = await client.request(method, f"{target_base}{endpoint_path}", headers=headers)

            # If request still succeeds with 200, still vulnerable!
            # If 403 or 401 or 404, it is FIXED!
            if res.status_code == 200:
                return {
                    "status": "still-vulnerable",
                    "status_code": res.status_code,
                    "message": f"Verification confirmed flaw persists! Target returned HTTP {res.status_code}."
                }
            else:
                return {
                    "status": "fixed",
                    "status_code": res.status_code,
                    "message": f"Verification confirmed fix is effective! Target returned HTTP {res.status_code}."
                }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Could not re-verify against target: {str(e)}"
            }

@router.post("/{finding_id}/explain", response_model=AIExplainResponse)
async def explain_finding_ai(finding_id: int):
    f, scan_id = find_in_memory_finding(finding_id)
    finding_dict = {
        "class": getattr(f, "finding_class", "BOLA"),
        "owasp_id": getattr(f, "owasp_id", "API1:2023"),
        "endpoint_method": getattr(f, "endpoint_method", "GET"),
        "endpoint_path": getattr(f, "endpoint_path", "/orders/{order_id}"),
        "expected": getattr(f, "expected", "HTTP 403 Forbidden"),
        "actual": getattr(f, "actual", "HTTP 200 OK"),
        "confidence": getattr(f, "confidence", "VERIFIED")
    }

    explanation_md = await ai_provider.explain(finding_dict)
    return AIExplainResponse(
        finding_id=finding_id,
        explanation_md=explanation_md,
        source="groq" if ai_provider.reasoning_llm else "template_fallback"
    )
