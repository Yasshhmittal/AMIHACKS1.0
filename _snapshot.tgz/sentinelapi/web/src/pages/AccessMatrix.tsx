import { useMemo, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Card, Empty, ErrorBox, Loading, SeverityBadge } from '../components/ui'
import { useFetch } from '../hooks/useFetch'
import type { Severity } from '../types'

interface MatrixCell {
  scan_id: number; endpoint_id: number; method: string; path: string
  identity: string; object_id: string | null; object_owner: string | null
  status: number; duration_ms: number; ownership_mismatch: boolean
  undocumented_fields: string[]; sensitive_fields: string[]
}

async function fetchMatrix(scanId: string): Promise<MatrixCell[]> {
  const r = await fetch(`/api/scans/${scanId}/matrix`)
  if (!r.ok) throw new Error(`GET /api/scans/${scanId}/matrix failed (${r.status})`)
  return r.json()
}

const IDENTITIES = ['anonymous', 'userA', 'userB', 'admin']

function statusColor(s: number, mismatch: boolean, sensitive: boolean): string {
  if (mismatch) return 'bg-[#dc2626]/25 text-[#dc2626] border-[#dc2626]/40'
  if (sensitive) return 'bg-[#ea580c]/20 text-[#ea580c] border-[#ea580c]/40'
  if (s >= 200 && s < 300) return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
  if (s === 401 || s === 403) return 'bg-slate-500/15 text-slate-400 border-slate-500/30'
  if (s === 404) return 'bg-slate-700/20 text-slate-500 border-slate-600/30'
  return 'bg-amber-500/15 text-amber-400 border-amber-500/30'
}

export default function AccessMatrix() {
  const { scanId = '' } = useParams()
  const { data, error, loading, reload } = useFetch(() => fetchMatrix(scanId), [scanId])
  const [selected, setSelected] = useState<MatrixCell | null>(null)

  // Group by unique endpoints
  const endpoints = useMemo(() => {
    if (!data) return []
    const seen = new Map<string, { method: string; path: string }>()
    data.forEach(c => {
      const key = `${c.method} ${c.path}`
      if (!seen.has(key)) seen.set(key, { method: c.method, path: c.path })
    })
    return [...seen.values()]
  }, [data])

  // Build lookup: "METHOD /path" -> identity -> cell
  const lookup = useMemo(() => {
    const m = new Map<string, Map<string, MatrixCell>>()
    data?.forEach(c => {
      const key = `${c.method} ${c.path}`
      if (!m.has(key)) m.set(key, new Map())
      m.get(key)!.set(c.identity, c)
    })
    return m
  }, [data])

  // Determine which identities are actually present
  const identities = useMemo(() => {
    if (!data) return IDENTITIES
    const s = new Set(data.map(c => c.identity))
    return IDENTITIES.filter(i => s.has(i))
  }, [data])

  if (error) return <ErrorBox msg={error} retry={reload} />
  if (loading) return <Loading rows={8} />
  if (!data || data.length === 0) return <Empty title="No matrix data" hint="Run a scan first to populate the access matrix." />

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">Access Matrix</h1>
        <p className="mt-1 text-sm text-dim">Authorization is a property of the (identity, endpoint, object) triple. One sweep tests them all.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[3fr_1fr]">
        {/* Matrix grid */}
        <Card className="overflow-auto p-0">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-line text-dim">
                <th className="sticky left-0 bg-panel px-3 py-3 font-semibold">Endpoint</th>
                {identities.map(id => (
                  <th key={id} className="px-3 py-3 text-center font-mono font-semibold">{id}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {endpoints.map(ep => {
                const key = `${ep.method} ${ep.path}`
                const row = lookup.get(key)
                return (
                  <tr key={key} className="border-t border-line hover:bg-white/[.02]">
                    <td className="sticky left-0 bg-panel px-3 py-2.5 font-mono">
                      <span className="mr-2 font-bold">{ep.method}</span>
                      <span className="text-dim">{ep.path}</span>
                    </td>
                    {identities.map(id => {
                      const cell = row?.get(id)
                      if (!cell) return <td key={id} className="px-3 py-2.5 text-center text-dim">—</td>
                      const cls = statusColor(cell.status, cell.ownership_mismatch, cell.sensitive_fields.length > 0)
                      return (
                        <td key={id} className="px-3 py-2.5 text-center">
                          <button
                            onClick={() => setSelected(cell)}
                            className={`inline-flex min-w-[3.5rem] items-center justify-center gap-1.5 rounded border px-2 py-1 font-mono font-bold transition hover:scale-105 ${cls}`}
                          >
                            {cell.status}
                            {cell.ownership_mismatch && <span title="Ownership mismatch">⚠</span>}
                            {cell.sensitive_fields.length > 0 && <span title="Sensitive fields">🔑</span>}
                          </button>
                        </td>
                      )
                    })}
                  </tr>
                )
              })}
            </tbody>
          </table>
        </Card>

        {/* Detail sidebar */}
        <div className="space-y-4">
          <Card className="p-4">
            <h2 className="mb-3 text-sm font-bold">Legend</h2>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2"><span className="size-3 rounded bg-emerald-500/40" /> 2xx – Allowed</div>
              <div className="flex items-center gap-2"><span className="size-3 rounded bg-slate-500/40" /> 401/403 – Denied</div>
              <div className="flex items-center gap-2"><span className="size-3 rounded bg-[#dc2626]/40" /> ⚠ Ownership mismatch</div>
              <div className="flex items-center gap-2"><span className="size-3 rounded bg-[#ea580c]/40" /> 🔑 Sensitive data exposed</div>
            </div>
          </Card>

          {selected && (
            <Card className="p-4">
              <h2 className="mb-3 text-sm font-bold">Cell Detail</h2>
              <div className="space-y-1.5 font-mono text-xs">
                <p><span className="text-dim">Endpoint:</span> {selected.method} {selected.path}</p>
                <p><span className="text-dim">Identity:</span> {selected.identity}</p>
                <p><span className="text-dim">Status:</span> <span className="font-bold">{selected.status}</span></p>
                <p><span className="text-dim">Latency:</span> {selected.duration_ms}ms</p>
                {selected.object_id && <p><span className="text-dim">Object:</span> #{selected.object_id} (owner: {selected.object_owner})</p>}
                {selected.ownership_mismatch && <p className="font-bold text-[#dc2626]">⚠ OWNERSHIP MISMATCH — caller ≠ owner</p>}
                {selected.sensitive_fields.length > 0 && (
                  <div>
                    <p className="text-dim">Sensitive fields:</p>
                    <ul className="ml-3 mt-1 space-y-0.5">
                      {selected.sensitive_fields.map(f => <li key={f} className="text-[#ea580c]">• {f}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            </Card>
          )}

          <Card className="p-4">
            <h2 className="mb-2 text-sm font-bold">Summary</h2>
            <p className="text-xs text-dim">{data.length} probes across {endpoints.length} endpoints × {identities.length} identities</p>
            <p className="mt-1 text-xs text-dim">{data.filter(c => c.ownership_mismatch).length} ownership mismatches detected</p>
            <p className="text-xs text-dim">{data.filter(c => c.sensitive_fields.length > 0).length} cells with sensitive data</p>
          </Card>
        </div>
      </div>
    </div>
  )
}
