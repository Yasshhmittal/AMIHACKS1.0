import { useMemo, useRef } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Card, ConfidenceBadge, Empty, ErrorBox, Loading, SEV_ORDER, SeverityBadge } from '../components/ui'
import { api } from '../api/client'
import { useFetch } from '../hooks/useFetch'
import type { Finding, Summary } from '../types'

const sevColor: Record<string, string> = {
  CRITICAL: '#dc2626', HIGH: '#ea580c', MEDIUM: '#ca8a04', LOW: '#2563eb', INFO: '#64748b'
}

export default function Report() {
  const { scanId = '' } = useParams()
  const scan = useFetch(() => api.scan(scanId), [scanId])
  const fnd = useFetch(() => api.findings(scanId), [scanId])
  const sum = useFetch(() => api.summary(scanId), [scanId])
  const printRef = useRef<HTMLDivElement>(null)

  if (scan.error || fnd.error) return <ErrorBox msg={(scan.error || fnd.error)!} retry={() => { scan.reload(); fnd.reload() }} />
  if (scan.loading || fnd.loading) return <Loading rows={8} />

  const s = scan.data!
  const all = fnd.data ?? []
  const summary = sum.data

  // Group findings by severity
  const grouped = useMemo(() => {
    const m = new Map<string, Finding[]>()
    SEV_ORDER.forEach(sev => m.set(sev, []))
    all.forEach(f => m.get(f.severity)?.push(f))
    return [...m.entries()].filter(([, v]) => v.length > 0)
  }, [all])

  const handlePrint = () => window.print()

  return (
    <div className="space-y-6" ref={printRef}>
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Security Audit Report</h1>
          <p className="mt-1 text-sm text-dim">Scan #{scanId} · {all.length} findings · Risk score {s.risk_score}</p>
        </div>
        <button onClick={handlePrint}
          className="rounded-lg border border-line px-4 py-2 text-sm font-semibold text-ink transition hover:bg-white/5 print:hidden">
          Print / Save PDF
        </button>
      </div>

      {/* Executive Summary */}
      <Card className="p-6">
        <h2 className="mb-4 text-lg font-bold">Executive Summary</h2>
        {summary?.text ? (
          <p className="whitespace-pre-wrap leading-7 text-sm">{summary.text}</p>
        ) : (
          <div className="space-y-3 text-sm">
            <p>SentinelAPI performed a zero-trust security scan against the target API.
              The scanner tested every endpoint against every configured identity, verifying authorization
              boundaries through real HTTP requests with ownership proof.</p>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <div><p className="text-xs text-dim">Endpoints</p><p className="font-mono text-xl font-bold">{summary?.total_endpoints ?? '—'}</p></div>
              <div><p className="text-xs text-dim">Requests</p><p className="font-mono text-xl font-bold">{s.requests_used}</p></div>
              <div><p className="text-xs text-dim">Findings</p><p className="font-mono text-xl font-bold">{all.length}</p></div>
              <div><p className="text-xs text-dim">Duration</p><p className="font-mono text-xl font-bold">{(s.duration_ms / 1000).toFixed(1)}s</p></div>
            </div>
          </div>
        )}
      </Card>

      {/* Severity Breakdown */}
      <Card className="p-6">
        <h2 className="mb-4 text-lg font-bold">Findings by Severity</h2>
        <div className="flex flex-wrap gap-6">
          {SEV_ORDER.map(sev => {
            const count = all.filter(f => f.severity === sev).length
            return (
              <div key={sev} className="flex items-center gap-3">
                <div className="size-10 rounded-lg flex items-center justify-center font-mono text-lg font-bold"
                  style={{ background: `color-mix(in srgb, ${sevColor[sev]} 20%, transparent)`, color: sevColor[sev] }}>
                  {count}
                </div>
                <span className="text-xs text-dim">{sev}</span>
              </div>
            )
          })}
        </div>
      </Card>

      {/* Findings Detail */}
      {grouped.map(([sev, findings]) => (
        <Card key={sev} className="p-6">
          <h2 className="mb-4 flex items-center gap-3 text-lg font-bold">
            <SeverityBadge s={sev as any} />
            {sev} ({findings.length})
          </h2>
          <div className="space-y-4">
            {findings.map(f => (
              <div key={f.id} className="rounded-lg border border-line p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <Link to={`/finding/${f.id}`} className="font-semibold hover:underline">{f.title}</Link>
                    <p className="mt-1 font-mono text-xs text-dim">{f.endpoint} · {f.owasp_id}</p>
                  </div>
                  <ConfidenceBadge c={f.confidence} />
                </div>
                <p className="mt-2 text-sm text-dim">{f.impact}</p>
                <div className="mt-3 rounded border border-line bg-bg p-3">
                  <p className="text-xs font-semibold text-dim">Remediation</p>
                  <p className="mt-1 text-sm">{f.remediation}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}

      {all.length === 0 && <Empty title="No findings" hint="This scan completed without any findings." />}

      {/* Footer */}
      <Card className="p-4 text-center text-xs text-dim print:border-0">
        <p>Generated by SentinelAPI Zero-Trust API Vulnerability Scanner</p>
        <p className="mt-1">This report is based on real HTTP evidence, not static analysis or AI inference.</p>
      </Card>
    </div>
  )
}
