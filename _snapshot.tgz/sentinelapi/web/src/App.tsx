import { Navigate, Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import NewScan from './pages/NewScan'
import LiveScan from './pages/LiveScan'
import Results from './pages/Results'
import FindingDetail from './pages/FindingDetail'
import AccessMatrix from './pages/AccessMatrix'
import Report from './pages/Report'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Navigate to="/scan/new" replace />} />
        <Route path="/scan/new" element={<NewScan />} />
        <Route path="/scan/:scanId/live" element={<LiveScan />} />
        <Route path="/scan/:scanId/results" element={<Results />} />
        <Route path="/scan/:scanId/matrix" element={<AccessMatrix />} />
        <Route path="/scan/:scanId/report" element={<Report />} />
        <Route path="/finding/:findingId" element={<FindingDetail />} />
      </Route>
    </Routes>
  )
}
